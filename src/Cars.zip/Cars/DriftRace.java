package Cars;

import java.util.List;

public class DriftRace extends Race{

    public DriftRace(){

    }

    public DriftRace(int length, String route, int prizePool, List<Car> participants){
        super(length, route, prizePool, participants);

    }


}
