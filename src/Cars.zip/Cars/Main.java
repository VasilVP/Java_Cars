package Cars;


public class Main {

    public static void main(String[] args){


       PerformanceCar performanceCar = new PerformanceCar();
       ShowCar showCar = new ShowCar();

       Race race = new Race();
       CasualRace casualRace = new CasualRace();
       DragRace dragRace = new DragRace();
       DriftRace driftRace = new DriftRace();

       Garage garage = new Garage();

    }
}
